/**
 * @file adm_dts_gw.h
 * @brief DTS gw interface
 * @details the APP call the interface to DTS gw
 * @author 
 * @version v0.1.0
 * @date 2021-2-08
 * @copyright www.abupdate.com
 */
#ifndef _ADM_DTS_DAEMON_LOADER_H_
#define _ADM_DTS_DAEMON_LOADER_H_

#include "adm_dts_common.h"

#ifdef __cplusplus
extern "C" {
#endif

#define EXPORT_FUN __attribute__((visibility("default")))


/**
 *******************************************************************************
 * @brief traerDaemon模块主入口
 * @note traerDaemon模块主入口。
 * 
 * @param soFileName	    [In] char * 日志桥接服务程序动态库的全路径文件名称
 * @param configFileName	[In] char * 日志桥接服务程序需要的配置文件全路文件名称
 *                           Note: support gw and passive mode. 
 *                                 suggest HMI/PC as gw;tbox as passive.
 * @return D32S 		0:successed, non-0: failed
 *******************************************************************************
 */
extern int adm_tracerDaemonStart(char *soFilenName, char *configFileName);

/*!
 *******************************************************************************
 * Exit the tracerDaemon module
 * \return	D32S  0:successed, non-0:failed 
 *******************************************************************************
 */
extern int adm_tracerDaemonStop(void);


#define ADM_DTS_GW_DEFAULT_SDK_VERSION      "tools_default_version_1.1.0"       //!< 定义默认的软件版本号

/*!
 *******************************************************************************
 * tools get software version number
 * \return	version format: ${PROJECT_NAME}_${ENV_PLATFORM}_${ADM_SDK_VERSION}_${COMPILE_DATE}_${GIT_COMMITID})
 *******************************************************************************
 */
extern char* adm_dtsGWGetSdkVersion(void);

#ifdef __cplusplus  // close out "C" linkage in case of c++ compiling
}
#endif
#endif


