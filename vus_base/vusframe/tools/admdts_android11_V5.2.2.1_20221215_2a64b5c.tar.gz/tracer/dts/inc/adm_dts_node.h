/**
 * @file adm_dts_node.h
 * @brief DTS node interface
 * @details the APP call the interface to dts node
 * @author abup
 * @version v0.1.0
 * @date 2021-2-08
 * @copyright www.abupdate.com
 */
#ifndef _ADM_DTS_NODE_H_
#define _ADM_DTS_NODE_H_

#include "adm_dts_common.h"

#ifdef __cplusplus
extern "C" {
#endif

#define EXPORT_FUN __attribute__((visibility("default")))


/**
 * @brief 模块名信息定义
 *
 */
typedef struct
{
    int eType;  //!<  模块名类型枚举值
    char* modName;  //!<  模块名称
} DTS_MOD_INFO_T;

typedef int (*LOG_TRACER_OUTPUT_CALLBACK_F)(char *otime, int iModID, int inLogLevel,const char* inFuncName, int inLineNumber,const char *format, ...);

extern void adm_logTracerRegister(LOG_TRACER_OUTPUT_CALLBACK_F logTracerHandler);

extern int dts_put_loginfo(char *otime, int iModID,int inLogLevel,const char* inFuncName,int inLineNumber,const char *format, ...);

extern int dts_put_raw_log(int iModID, int inLogLevel, const void* pRawData, unsigned short cbRawDataLen);

/**
 *******************************************************************************
 * @brief traerNode模块主入口
 * @note traerNode模块主入口。
 * 
 * @param appID	[Out] char * 	 日志工具中对应项AppId的名称(appID长度必须 <= 4)
 * @return int 		0:successed, non-0: failed
 *******************************************************************************
 */
extern int adm_tracer_entry(char *appID, DTS_MOD_INFO_T modList[]);


/*!
 *******************************************************************************
 * Exit the tracerNode module
 * \return	int  0:successed, non-0:failed 
 *******************************************************************************
 */
extern int adm_tracer_exit(void);

/**
 * @brief callback function for handling injection message from DtsTool client
 * @param service_id  service id >= 4096
 * @param data        pointer of message data
 * @param length      length of message data
 * @param priv_data   same as priv_data argument passed to dts_register_injection_callback
 * @return int 		  0:successed, non-0: failed 
 */
typedef int (*DTS_LOG_INJECTION_CALLBACK)(unsigned int service_id, void* data, unsigned int length, void* priv_data);

/**
 *******************************************************************************
 * @brief 注册injection控制回调函数
 * @note 用于接收工具客户端发过来的控制命令，客户端是按照 app/context, serviceId 发送的
 * 
 * @param iModID      module index
 * @param service_id  service id >= 4096
 * @param callback    function pointer to callback function for handling injection message from DtsTool client
 * @param priv_data   private data, it can be NULL
 * @return int 		  0:successed, non-0: failed 
*/
extern int dts_register_injection_callback(int iModID, unsigned int service_id, 
                        DTS_LOG_INJECTION_CALLBACK callback, void* priv_data);


#define ADM_DTS_NODE_DEFAULT_SDK_VERSION      "tools_default_version_1.1.0"       //!< 定义默认的软件版本号

/*!
 *******************************************************************************
 * tools get software version number
 * \return	version format: ${PROJECT_NAME}_${ENV_PLATFORM}_${ADM_SDK_VERSION}_${COMPILE_DATE}_${GIT_COMMITID})
 *******************************************************************************
 */
extern char* adm_dtsNodeGetSdkVersion(void);

#ifdef __cplusplus  // close out "C" linkage in case of c++ compiling
}
#endif
#endif


