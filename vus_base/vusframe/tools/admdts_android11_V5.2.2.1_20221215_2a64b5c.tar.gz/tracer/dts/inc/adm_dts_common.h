/**
 * @file adm_dts_common.h
 * @brief DTS common
 * @details dts common definition
 * @author abup
 * @version v0.1.0
 * @date 2021-2-08
 * @copyright www.abupdate.com
 */
#ifndef _ADM_DTS_COMMON_H_
#define _ADM_DTS_COMMON_H_

#ifdef __cplusplus
extern "C" {
#endif

#define EXPORT_FUN __attribute__((visibility("default")))

/* output log's level */
#define DTS_LVL_ASSERT                      0
#define DTS_LVL_ERROR                       1
#define DTS_LVL_WARN                        2
#define DTS_LVL_INFO                        3
#define DTS_LVL_DEBUG                       4
#define DTS_LVL_VERBOSE                     5

#ifndef NULL
  #ifdef __cplusplus
    #define	NULL	0
  #else
    #define	NULL	((void *)0)
  #endif
#endif

/*!
 * @brief Tracer 错误类型
 */
typedef enum enDTSErrorCode_ 
{
    ADM_DTS_ECODE_LOAD_START_SUCCESS = 0,   //!< 加载并启动成功
    ADM_DTS_ECODE_SOFILE_INVALID,        //!< so文件路径和文件名称为空
    ADM_DTS_ECODE_CONFIGFILE_INVALID,       //!< 配置文件路径及文件名为空
    ADM_DTS_ECODE_SOFILE_CANNOT_LOAD,       //!< so无法加载
    ADM_DTS_ECODE_SYM_NOT_FOUND,            //!< sym未找到
    ADM_DTS_ECODE_START_FAIL,               //!< 启动失败
    ADM_DTS_ECODE_CLIENT_ALREADY_INITED,    //!< 客户端已经初始化
    ADM_DTS_ECODE_DLT_ERROR,                //!< dlt 内部返回错误
    ADM_DTS_ECODE_CLIENT_NOT_INITED,        //!< 客户端未初始化
    ADM_DTS_ECODE_WRONG_PARAM,              //!< 参数错误
} ADM_DTS_ECODE_E;

#ifdef __cplusplus  // close out "C" linkage in case of c++ compiling
}
#endif
#endif


