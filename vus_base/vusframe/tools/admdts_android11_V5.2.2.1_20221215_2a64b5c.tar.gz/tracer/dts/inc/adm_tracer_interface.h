#ifndef __ADM_TRACER_INTERFACE_H__
#define __ADM_TRACER_INTERFACE_H__

#include "adm_dts_node.h"

#include "adm_dts_daemon_loader.h"

#endif //__ADM_TRACER_INTERFACE_H__