/**
 * @file adm_dts_node.h
 * @brief DTS node interface
 * @details the APP call the interface to dts node
 * @author abup
 * @version v0.1.0
 * @date 2021-2-08
 * @copyright www.abupdate.com
 */
#ifndef _ADM_DTS_NODE_H_
#define _ADM_DTS_NODE_H_

#include "adm_dts_common.h"

#ifdef __cplusplus
extern "C" {
#endif

#define EXPORT_FUN __attribute__((visibility("default")))


/**
 * @brief 模块名信息定义
 *
 */
typedef struct
{
    int eType;  //!<  模块名类型枚举值
    char* modName;  //!<  模块名称
} DTS_MOD_INFO_T;

typedef int (*LOG_TRACER_OUTPUT_CALLBACK_F)(char *otime, int iModID, int inLogLevel,const char* inFuncName, int inLineNumber,const char *format, ...);

extern void adm_logTracerRegister(LOG_TRACER_OUTPUT_CALLBACK_F logTracerHandler);

extern int dts_put_loginfo(char *otime, int iModID,int inLogLevel,const char* inFuncName,int inLineNumber,const char *format, ...);

/**
 *******************************************************************************
 * @brief traerNode模块主入口
 * @note traerNode模块主入口。
 * 
 * @param appID	[Out] char * 	 日志工具中对应项AppId的名称(appID长度必须 <= 4)
 * @return int 		0:successed, non-0: failed
 *******************************************************************************
 */
extern int adm_tracer_entry(char *appID, DTS_MOD_INFO_T modList[]);


/*!
 *******************************************************************************
 * Exit the tracerNode module
 * \return	int  0:successed, non-0:failed 
 *******************************************************************************
 */
extern int adm_tracer_exit(void);



#define ADM_DTS_NODE_DEFAULT_SDK_VERSION      "tools_default_version_1.1.0"       //!< 定义默认的软件版本号

/*!
 *******************************************************************************
 * tools get software version number
 * \return	version format: ${PROJECT_NAME}_${ENV_PLATFORM}_${ADM_SDK_VERSION}_${COMPILE_DATE}_${GIT_COMMITID})
 *******************************************************************************
 */
extern char* adm_dtsNodeGetSdkVersion(void);

#ifdef __cplusplus  // close out "C" linkage in case of c++ compiling
}
#endif
#endif


